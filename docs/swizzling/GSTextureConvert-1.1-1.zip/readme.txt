--------------------------------------------------------------------------
- Sample Code: 
- Author: Victor Suba
- Date: March 21, 2003
- Library Version: N/A
--------------------------------------------------------------------------



	---------------
	- Description -
	---------------
	Originally contributed on the newsgroups by Victor Suba, this code
	provides a software simulation of the GS internal memory. Functions
	are provided to write to the GS in one texture format, and the read
	back from the GS in another texture format. This can be used to calculate
	swizzled textures for faster upload to the GS. For example to pre-swizzle
	a 4bit texture to 32bit you would write as 4bit and then read back as 32bit
	for the swizzled version.


	---------------
	- Changes -
	---------------
	March 11 (v1.0): First version taken from newsgroups with Z modes added
	March 21 (v1.1): Put back in commented out lines of dbw>>=1 for PSMT4 and PSMT8
		  	 texture reads and writes.
